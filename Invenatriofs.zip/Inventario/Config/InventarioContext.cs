﻿using Microsoft.EntityFrameworkCore;
using Inventario.Models;


namespace Inventario.Config
{
    public class InventarioContext:DbContext
    {
       
        
        
        public InventarioContext(DbContextOptions contexto):base(contexto) {}


       //Aqui crea las tablas
        public DbSet<ClienteModel> Clientes { get; set; }
    }
}
    
